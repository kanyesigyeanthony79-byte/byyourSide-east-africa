document.getElementById("requestForm").addEventListener("submit", function (event) {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const location = document.getElementById("location").value.trim();
  const service = document.getElementById("service").value;
  const dates = document.getElementById("dates").value.trim();
  const details = document.getElementById("details").value.trim();

  const message =
`Hello ByYourSide East Africa,

I would like to request a companion.

Name: ${name}
Phone/WhatsApp: ${phone}
Location: ${location}
Service needed: ${service}
Dates/timing: ${dates || "Not specified"}
Details: ${details || "Not specified"}`;

  window.open("https://wa.me/256787612459?text=" + encodeURIComponent(message), "_blank");
});
